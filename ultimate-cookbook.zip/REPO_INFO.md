# Repository Info

**Repo name:** `ultimate-cookbook`

**Short description:** A big, organized collection of recipes in plain Markdown: one file per recipe, grouped into category folders, each with ingredients and step-by-step instructions.

**Suggested topics:** recipes, cookbook, cooking, markdown, food
